<?php 
     $path =  "http://localhost/Upwork/pricing-estimator-final/";
?>